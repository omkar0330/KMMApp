package com.example.shared.accessibility

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AccessibilityServiceLogger : AccessibilityService() {

    private val TAG = "AccessibilityLogger"

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val nodeInfo = event.source
            if (nodeInfo != null) {
                val text = nodeInfo.text ?: ""
                val packageName = event.packageName ?: ""
                Log.d(TAG, "User clicked on: $text in app: $packageName")
                nodeInfo.recycle()
            }
        } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName ?: ""
            Log.d(TAG, "Screen changed, current app: $packageName")
            rootInActiveWindow?.let {
                logAllVisibleText(it)
                it.recycle()
            }
        }
    }

    private fun logAllVisibleText(node: AccessibilityNodeInfo) {
        if (node.text != null && node.text.isNotBlank()) {
            Log.d(TAG, "Visible Text: ${node.text}")
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let {
                logAllVisibleText(it)
                it.recycle()
            }
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility Service Interrupted")
    }
}
