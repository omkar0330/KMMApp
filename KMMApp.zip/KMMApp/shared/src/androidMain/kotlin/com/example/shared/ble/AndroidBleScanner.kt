package com.example.shared.ble

import android.annotation.SuppressLint
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import com.example.shared.model.BleDevice
import kotlinx.coroutines.flow.MutableStateFlow

@SuppressLint("MissingPermission")
class AndroidBleScanner {
    val scannedDevices = MutableStateFlow<List<BleDevice>>(emptyList())

    val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = BleDevice(
                name = result.device.name,
                identifier = result.device.address,
                rssi = result.rssi
            )
            
            val currentList = scannedDevices.value.toMutableList()
            val existingIndex = currentList.indexOfFirst { it.identifier == device.identifier }
            if (existingIndex != -1) {
                currentList[existingIndex] = device
            } else {
                currentList.add(device)
            }
            scannedDevices.value = currentList
        }
    }
}
