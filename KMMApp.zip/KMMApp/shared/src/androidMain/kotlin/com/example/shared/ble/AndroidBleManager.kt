package com.example.shared.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.util.Log
import com.example.shared.model.BleDevice
import com.example.shared.model.ConnectionState
import com.example.shared.service.BleService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.*

@SuppressLint("MissingPermission")
class AndroidBleManager(private val context: Context) : BleService {

    private val bluetoothManager by lazy { context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager }
    private val bluetoothAdapter by lazy { bluetoothManager.adapter }
    private val bleScanner by lazy { bluetoothAdapter?.bluetoothLeScanner }

    private val _scannedDevices = MutableStateFlow<List<BleDevice>>(emptyList())
    override val scannedDevices: StateFlow<List<BleDevice>> = _scannedDevices.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _batteryLevel = MutableStateFlow<Int?>(null)
    override val batteryLevel: StateFlow<Int?> = _batteryLevel.asStateFlow()

    private val _customGattData = MutableStateFlow<String?>(null)
    override val customGattData: StateFlow<String?> = _customGattData.asStateFlow()

    private var bluetoothGatt: BluetoothGatt? = null

    private val BATTERY_SERVICE_UUID = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb")
    private val BATTERY_LEVEL_CHARACTERISTIC_UUID = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb")
    private val CCC_DESCRIPTOR_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = BleDevice(
                name = result.device.name ?: "Unknown Device",
                identifier = result.device.address,
                rssi = result.rssi
            )
            val currentList = _scannedDevices.value.toMutableList()
            val existingIndex = currentList.indexOfFirst { it.identifier == device.identifier }
            if (existingIndex != -1) {
                currentList[existingIndex] = device
            } else {
                currentList.add(device)
            }
            _scannedDevices.value = currentList
        }
        
        override fun onScanFailed(errorCode: Int) {
            Log.e("BleManager", "Scan failed with error: $errorCode")
        }
    }

    override fun startScan() {
        if (bluetoothAdapter?.isEnabled == false) {
            Log.w("BleManager", "Bluetooth is disabled")
            return
        }
        _scannedDevices.value = emptyList()
        bleScanner?.startScan(scanCallback)
    }

    override fun stopScan() {
        bleScanner?.stopScan(scanCallback)
    }

    override fun connect(device: BleDevice) {
        if (bluetoothAdapter?.isEnabled == false) return
        
        _connectionState.value = ConnectionState.Connecting
        val bluetoothDevice = bluetoothAdapter?.getRemoteDevice(device.identifier)
        bluetoothGatt = bluetoothDevice?.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    override fun disconnect() {
        bluetoothGatt?.disconnect()
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            Log.d("BleManager", "onConnectionStateChange: status=$status, newState=$newState")
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    _connectionState.value = ConnectionState.Connected
                    gatt.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    _connectionState.value = ConnectionState.Disconnected
                    _batteryLevel.value = null
                    gatt.close()
                    bluetoothGatt = null
                    
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        // Attempt reconnect if it wasn't a clean disconnect
                        Log.d("BleManager", "Unexpected disconnect, attempting reconnect...")
                        // In a real app, you might want a delay here
                    }
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d("BleManager", "Services discovered")
                val batteryService = gatt.getService(BATTERY_SERVICE_UUID)
                batteryService?.getCharacteristic(BATTERY_LEVEL_CHARACTERISTIC_UUID)?.let { characteristic ->
                    Log.d("BleManager", "Battery characteristic found")
                    gatt.readCharacteristic(characteristic)
                    
                    // Enable notifications for battery level updates
                    gatt.setCharacteristicNotification(characteristic, true)
                    characteristic.getDescriptor(CCC_DESCRIPTOR_UUID)?.let { descriptor ->
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(descriptor)
                    }
                }
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                updateCharacteristic(characteristic)
            }
        }

        override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                updateCharacteristic(characteristic, value)
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            updateCharacteristic(characteristic)
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            updateCharacteristic(characteristic, value)
        }

        private fun updateCharacteristic(characteristic: BluetoothGattCharacteristic, value: ByteArray? = null) {
            if (characteristic.uuid == BATTERY_LEVEL_CHARACTERISTIC_UUID) {
                val batteryLevelValue = value?.get(0)?.toInt()?.let { it and 0xFF } 
                    ?: characteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, 0)
                Log.d("BleManager", "Battery level updated: $batteryLevelValue")
                _batteryLevel.value = batteryLevelValue
            }
        }
    }
}
