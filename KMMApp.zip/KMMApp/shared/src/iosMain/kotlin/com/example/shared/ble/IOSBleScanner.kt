package com.example.shared.ble

import com.example.shared.model.BleDevice
import kotlinx.coroutines.flow.MutableStateFlow
import platform.CoreBluetooth.*
import platform.Foundation.NSNumber
import platform.darwin.NSObject

class IOSBleScanner : NSObject(), CBCentralManagerDelegateProtocol {
    private val centralManager = CBCentralManager(this, null)
    val scannedDevices = MutableStateFlow<List<BleDevice>>(emptyList())

    override fun centralManagerDidUpdateState(central: CBCentralManager) {
        when (central.state) {
            CBManagerStatePoweredOn -> {
                central.scanForPeripheralsWithServices(null, null)
            }
            else -> {
                // Handle other states (off, unauthorized, etc.)
            }
        }
    }

    override fun centralManager(
        central: CBCentralManager,
        didDiscoverPeripheral: CBPeripheral,
        advertisementData: Map<Any?, *>,
        RSSI: NSNumber
    ) {
        val device = BleDevice(
            name = didDiscoverPeripheral.name,
            identifier = didDiscoverPeripheral.identifier.UUIDString,
            rssi = RSSI.intValue
        )
        
        val currentList = scannedDevices.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.identifier == device.identifier }
        if (existingIndex != -1) {
            currentList[existingIndex] = device
        } else {
            currentList.add(device)
        }
        scannedDevices.value = currentList
    }
}
