package com.example.shared

actual fun platform() = "iOS"