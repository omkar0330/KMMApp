package com.example.shared.ble

import com.example.shared.model.BleDevice
import com.example.shared.model.ConnectionState
import com.example.shared.service.BleService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import platform.CoreBluetooth.*
import platform.Foundation.NSNumber
import platform.Foundation.NSError
import platform.darwin.NSObject
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCSignatureOverride
import kotlinx.cinterop.get
import kotlinx.cinterop.reinterpret
import platform.posix.uint8_tVar

@OptIn(ExperimentalForeignApi::class)
class IOSBleManager : NSObject(), BleService, CBCentralManagerDelegateProtocol, CBPeripheralDelegateProtocol {

    private val centralManager = CBCentralManager(this, null)

    private val _scannedDevices = MutableStateFlow<List<BleDevice>>(emptyList())
    override val scannedDevices: StateFlow<List<BleDevice>> = _scannedDevices.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _batteryLevel = MutableStateFlow<Int?>(null)
    override val batteryLevel: StateFlow<Int?> = _batteryLevel.asStateFlow()

    private val _customGattData = MutableStateFlow<String?>(null)
    override val customGattData: StateFlow<String?> = _customGattData.asStateFlow()

    private var peripheral: CBPeripheral? = null
    private val discoveredPeripherals = mutableMapOf<String, CBPeripheral>()

    private val batteryServiceUuid = CBUUID.UUIDWithString("180F")
    private val batteryLevelCharacteristicUuid = CBUUID.UUIDWithString("2A19")

    override fun startScan() {
        _scannedDevices.value = emptyList()
        discoveredPeripherals.clear()
        if (centralManager.state == CBManagerStatePoweredOn) {
            centralManager.scanForPeripheralsWithServices(null, null)
        }
    }

    override fun stopScan() {
        centralManager.stopScan()
    }

    override fun connect(device: BleDevice) {
        val targetPeripheral = discoveredPeripherals[device.identifier]
        if (targetPeripheral != null) {
            _connectionState.value = ConnectionState.Connecting
            peripheral = targetPeripheral
            centralManager.connectPeripheral(targetPeripheral, null)
        }
    }

    override fun disconnect() {
        peripheral?.let { centralManager.cancelPeripheralConnection(it) }
        peripheral = null
        _connectionState.value = ConnectionState.Disconnected
    }

    override fun centralManagerDidUpdateState(central: CBCentralManager) {
        // Handle state changes if needed
    }

    override fun centralManager(central: CBCentralManager, didDiscoverPeripheral: CBPeripheral, advertisementData: Map<Any?, *>, RSSI: NSNumber) {
        val device = BleDevice(
            name = didDiscoverPeripheral.name,
            identifier = didDiscoverPeripheral.identifier.UUIDString,
            rssi = RSSI.intValue
        )
        
        discoveredPeripherals[device.identifier] = didDiscoverPeripheral
        
        val currentList = _scannedDevices.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.identifier == device.identifier }
        if (existingIndex != -1) {
            currentList[existingIndex] = device
        } else {
            currentList.add(device)
        }
        _scannedDevices.value = currentList
    }

    override fun centralManager(central: CBCentralManager, didConnectPeripheral: CBPeripheral) {
        _connectionState.value = ConnectionState.Connected
        peripheral = didConnectPeripheral
        peripheral?.delegate = this
        peripheral?.discoverServices(listOf(batteryServiceUuid))
    }


    @ObjCSignatureOverride
    override fun centralManager(central: CBCentralManager, didFailToConnectPeripheral: CBPeripheral, error: NSError?) {
        _connectionState.value = ConnectionState.Disconnected
    }

    @ObjCSignatureOverride
    override fun centralManager(central: CBCentralManager, didDisconnectPeripheral: CBPeripheral, error: NSError?) {
        _connectionState.value = ConnectionState.Disconnected
        peripheral = null
        if (error != null) {
            _connectionState.value = ConnectionState.Reconnecting
            central.connectPeripheral(didDisconnectPeripheral, null)
        }
    }

    override fun peripheral(peripheral: CBPeripheral, didDiscoverServices: NSError?) {
        if (didDiscoverServices != null) return
        
        peripheral.services?.forEach { service ->
            val cbService = service as CBService
            peripheral.discoverCharacteristics(listOf(batteryLevelCharacteristicUuid), cbService)
        }
    }

    override fun peripheral(peripheral: CBPeripheral, didDiscoverCharacteristicsForService: CBService, error: NSError?) {
        if (error != null) return
        
        didDiscoverCharacteristicsForService.characteristics?.forEach { characteristic ->
            val cbCharacteristic = characteristic as CBCharacteristic
            if (cbCharacteristic.UUID == batteryLevelCharacteristicUuid) {
                peripheral.readValueForCharacteristic(cbCharacteristic)
                peripheral.setNotifyValue(true, cbCharacteristic)
            }
        }
    }

    override fun peripheral(peripheral: CBPeripheral, didUpdateValueForCharacteristic: CBCharacteristic, error: NSError?) {
        if (error != null) return
        
        if (didUpdateValueForCharacteristic.UUID == batteryLevelCharacteristicUuid) {
            val value = didUpdateValueForCharacteristic.value
            value?.let { data ->
                if (data.length > 0u) {
                    val bytes = data.bytes?.reinterpret<uint8_tVar>()
                    val batteryLevel = bytes?.get(0)?.toInt() ?: 0
                    _batteryLevel.value = batteryLevel
                }
            }
        }
    }
}
