package com.example.shared.model

data class BleDevice(
    val name: String?,
    val identifier: String,  // MAC (Android) / UUID (iOS)
    val rssi: Int
)