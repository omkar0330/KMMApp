package com.example.shared.util

import kotlin.experimental.and

object GattParser {

    fun parseBatteryLevel(value: ByteArray?): Int? {
        if (value == null || value.isEmpty()) return null
        // Battery level is usually the first byte
        return value[0].toInt() and 0xFF
    }

    fun parseHeartRate(value: ByteArray?): Int? {
        if (value == null || value.isEmpty()) return null
        
        val flags = value[0].toInt()
        val isFormat8Bit = (flags and 0x01) == 0
        
        return if (isFormat8Bit) {
            if (value.size >= 2) value[1].toInt() and 0xFF else null
        } else {
            if (value.size >= 3) {
                // 16-bit format (little endian)
                ((value[1].toInt() and 0xFF) or ((value[2].toInt() and 0xFF) shl 8))
            } else null
        }
    }

    fun bytesToHex(bytes: ByteArray?): String {
        if (bytes == null) return ""
        val hexChars = "0123456789ABCDEF"
        val result = StringBuilder(bytes.size * 2)
        for (byte in bytes) {
            val i = byte.toInt()
            result.append(hexChars[i shr 4 and 0x0f])
            result.append(hexChars[i and 0x0f])
        }
        return result.toString()
    }
}
