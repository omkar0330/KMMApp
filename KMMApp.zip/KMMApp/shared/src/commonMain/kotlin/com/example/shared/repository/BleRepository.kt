package com.example.shared.repository

import com.example.shared.model.BleDevice
import com.example.shared.model.ConnectionState
import com.example.shared.service.BleService
import kotlinx.coroutines.flow.StateFlow

class BleRepository(private val service: BleService) {
    val scannedDevices: StateFlow<List<BleDevice>> = service.scannedDevices
    val connectionState: StateFlow<ConnectionState> = service.connectionState
    val batteryLevel: StateFlow<Int?> = service.batteryLevel
    val customGattData: StateFlow<String?> = service.customGattData

    fun startScan() {
        service.startScan()
    }

    fun stopScan() {
        service.stopScan()
    }

    fun connect(device: BleDevice) {
        service.connect(device)
    }

    fun disconnect() {
        service.disconnect()
    }
}
