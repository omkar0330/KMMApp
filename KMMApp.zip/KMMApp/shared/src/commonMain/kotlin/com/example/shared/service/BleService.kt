package com.example.shared.service

import com.example.shared.model.BleDevice
import com.example.shared.model.ConnectionState
import kotlinx.coroutines.flow.StateFlow

interface BleService {
    val scannedDevices: StateFlow<List<BleDevice>>
    val connectionState: StateFlow<ConnectionState>
    val batteryLevel: StateFlow<Int?>
    val customGattData: StateFlow<String?>

    fun startScan()
    fun stopScan()
    fun connect(device: BleDevice)
    fun disconnect()
}
