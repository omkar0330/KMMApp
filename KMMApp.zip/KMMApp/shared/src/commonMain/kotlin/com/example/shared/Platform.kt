package com.example.shared

expect fun platform(): String