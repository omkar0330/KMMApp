package com.example.kmmapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.shared.ble.AndroidBleManager

class BleForegroundService : Service() {

    private lateinit var bleManager: AndroidBleManager

    override fun onCreate() {
        super.onCreate()
        bleManager = AndroidBleManager(this)
        createNotificationChannel()
        val notification = createNotification()
        startForeground(1, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val deviceAddress = intent?.getStringExtra("device_address")

        when (action) {
            "START_SCAN" -> bleManager.startScan()
            "STOP_SCAN" -> bleManager.stopScan()
            "CONNECT" -> {
                // Here we would need a way to pass the BleDevice or at least address
                // For now, this is a simplified version.
            }
            "DISCONNECT" -> bleManager.disconnect()
        }

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "BLE Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BLE Service")
            .setContentText("Maintaining BLE connection in background")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "BleServiceChannel"
    }
}
