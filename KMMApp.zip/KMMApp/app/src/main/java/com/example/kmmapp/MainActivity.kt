package com.example.kmmapp

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.kmmapp.ui.theme.KMMAppTheme
import com.example.shared.ble.AndroidBleManager
import com.example.shared.model.BleDevice
import com.example.shared.model.ConnectionState
import com.example.shared.repository.BleRepository
import com.example.shared.service.BleService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainActivity : ComponentActivity() {

    private val bleRepository by lazy {
        BleRepository(AndroidBleManager(this))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KMMAppTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    PermissionWrapper(modifier = Modifier.padding(innerPadding)) {
                        BleDeviceScreen(repository = bleRepository)
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionWrapper(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    } else {
        listOf(
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    var allPermissionsGranted by remember {
        mutableStateOf(
            permissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        allPermissionsGranted = result.values.all { it }
    }

    if (allPermissionsGranted) {
        Box(modifier = modifier) {
            content()
        }
    } else {
        Column(
            modifier = modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Permissions required for BLE scanning.")
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { launcher.launch(permissions.toTypedArray()) }) {
                Text("Grant Permissions")
            }
        }
    }
}

@Composable
fun BleDeviceScreen(repository: BleRepository, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val devices by repository.scannedDevices.collectAsState()
    val connectionState by repository.connectionState.collectAsState()
    val battery by repository.batteryLevel.collectAsState()
    
    val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    val bluetoothAdapter = bluetoothManager.adapter
    
    var isBluetoothEnabled by remember { mutableStateOf(bluetoothAdapter?.isEnabled == true) }
    var showConnectDialog by remember { mutableStateOf(false) }
    var showDisconnectDialog by remember { mutableStateOf(false) }
    var deviceToConnect by remember { mutableStateOf<BleDevice?>(null) }
    var connectedDeviceAddress by remember { mutableStateOf<String?>(null) }

    // Track the address of the device we are connected to
    LaunchedEffect(connectionState) {
        if (connectionState == ConnectionState.Disconnected) {
            connectedDeviceAddress = null
        } else if (connectionState == ConnectionState.Connected) {
            connectedDeviceAddress = deviceToConnect?.identifier
        }
    }
    
    // Check bluetooth state periodically
    LaunchedEffect(Unit) {
        while(true) {
            isBluetoothEnabled = bluetoothAdapter?.isEnabled == true
            delay(2000)
        }
    }

    val enableBluetoothLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    LaunchedEffect(isBluetoothEnabled) {
        if (isBluetoothEnabled) {
            repository.startScan()
        }
    }

    // Connect Confirmation Dialog
    if (showConnectDialog && deviceToConnect != null) {
        AlertDialog(
            onDismissRequest = { showConnectDialog = false },
            title = { Text("Connect to Device") },
            text = { Text("Do you want to connect with ${deviceToConnect?.name ?: "this device"}?") },
            confirmButton = {
                Button(onClick = {
                    repository.connect(deviceToConnect!!)
                    showConnectDialog = false
                }) {
                    Text("Connect")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConnectDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Disconnect Confirmation Dialog
    if (showDisconnectDialog) {
        AlertDialog(
            onDismissRequest = { showDisconnectDialog = false },
            title = { Text("Disconnect Device") },
            text = { Text("Do you want to disconnect from this device?") },
            confirmButton = {
                Button(
                    onClick = {
                        repository.disconnect()
                        showDisconnectDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Disconnect")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDisconnectDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        if (!isBluetoothEnabled) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Bluetooth is disabled",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Text(
                        text = "Please turn on your Bluetooth to scan and connect.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { 
                            val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                            enableBluetoothLauncher.launch(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Turn On Bluetooth")
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Scanned BLE Devices",
                style = MaterialTheme.typography.titleLarge
            )
            
            ConnectionStatusBadge(connectionState)
        }
        
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(devices) { device ->
                val isConnected = connectedDeviceAddress == device.identifier
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isConnected) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    onClick = { 
                        if (connectionState == ConnectionState.Disconnected) {
                            deviceToConnect = device
                            showConnectDialog = true
                        } else if (isConnected) {
                            showDisconnectDialog = true
                        }
                    }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = device.name ?: "Unknown Device",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (isConnected) Color(0xFF2E7D32) else Color.Unspecified
                                )
                                Text(
                                    text = "Address: ${device.identifier}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "RSSI: ${device.rssi} dBm",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            if (isConnected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Connected",
                                    tint = Color(0xFF4CAF50)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (connectionState == ConnectionState.Connected) 
                    Color(0xFFFFEBEE)
                else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Connected Device Info",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Status: ${if (connectionState == ConnectionState.Connected) "Connected" else "Not Connected"}",
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    text = "Battery Level: ${battery?.let { "$it%" } ?: "--"}",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(
            onClick = { repository.startScan() },
            modifier = Modifier.fillMaxWidth(),
            enabled = isBluetoothEnabled
        ) {
            Text("Refresh Scan")
        }
    }
}

@Composable
fun ConnectionStatusBadge(state: ConnectionState) {
    val color = when (state) {
        ConnectionState.Connected -> Color(0xFF4CAF50)
        ConnectionState.Connecting -> Color(0xFFFFC107)
        ConnectionState.Reconnecting -> Color(0xFFFF9800)
        ConnectionState.Disconnected -> Color(0xFFF44336)
    }
    
    val text = when (state) {
        ConnectionState.Connected -> "Connected"
        ConnectionState.Connecting -> "Connecting"
        ConnectionState.Reconnecting -> "Reconnecting"
        ConnectionState.Disconnected -> "Disconnected"
    }

    Surface(
        color = color,
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelMedium,
            color = Color.White
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewBleDeviceScreen() {
    val mockService = object : BleService {
        override val scannedDevices: StateFlow<List<BleDevice>> = MutableStateFlow(
            listOf(BleDevice("Demo Device", "00:11:22:33:44:55", -60))
        ).asStateFlow()
        override val connectionState: StateFlow<ConnectionState> = MutableStateFlow(ConnectionState.Connected).asStateFlow()
        override val batteryLevel: StateFlow<Int?> = MutableStateFlow(85).asStateFlow()
        override val customGattData: StateFlow<String?> = MutableStateFlow(null).asStateFlow()

        override fun startScan() {}
        override fun stopScan() {}
        override fun connect(device: BleDevice) {}
        override fun disconnect() {}
    }

    KMMAppTheme {
        BleDeviceScreen(repository = BleRepository(mockService))
    }
}
